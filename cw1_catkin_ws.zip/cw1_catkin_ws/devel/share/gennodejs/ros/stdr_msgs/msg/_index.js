
"use strict";

let CO2SensorMeasurementMsg = require('./CO2SensorMeasurementMsg.js');
let CO2Source = require('./CO2Source.js');
let RfidTagVector = require('./RfidTagVector.js');
let Noise = require('./Noise.js');
let ThermalSensorMeasurementMsg = require('./ThermalSensorMeasurementMsg.js');
let CO2SensorMsg = require('./CO2SensorMsg.js');
let RfidTag = require('./RfidTag.js');
let FootprintMsg = require('./FootprintMsg.js');
let SoundSensorMeasurementMsg = require('./SoundSensorMeasurementMsg.js');
let ThermalSourceVector = require('./ThermalSourceVector.js');
let SoundSensorMsg = require('./SoundSensorMsg.js');
let RfidSensorMeasurementMsg = require('./RfidSensorMeasurementMsg.js');
let RobotMsg = require('./RobotMsg.js');
let ThermalSource = require('./ThermalSource.js');
let ThermalSensorMsg = require('./ThermalSensorMsg.js');
let SoundSourceVector = require('./SoundSourceVector.js');
let CO2SourceVector = require('./CO2SourceVector.js');
let KinematicMsg = require('./KinematicMsg.js');
let LaserSensorMsg = require('./LaserSensorMsg.js');
let RfidSensorMsg = require('./RfidSensorMsg.js');
let SoundSource = require('./SoundSource.js');
let RobotIndexedVectorMsg = require('./RobotIndexedVectorMsg.js');
let SonarSensorMsg = require('./SonarSensorMsg.js');
let RobotIndexedMsg = require('./RobotIndexedMsg.js');
let RegisterRobotActionFeedback = require('./RegisterRobotActionFeedback.js');
let DeleteRobotActionFeedback = require('./DeleteRobotActionFeedback.js');
let SpawnRobotAction = require('./SpawnRobotAction.js');
let SpawnRobotActionFeedback = require('./SpawnRobotActionFeedback.js');
let DeleteRobotActionGoal = require('./DeleteRobotActionGoal.js');
let RegisterRobotActionResult = require('./RegisterRobotActionResult.js');
let SpawnRobotActionResult = require('./SpawnRobotActionResult.js');
let DeleteRobotResult = require('./DeleteRobotResult.js');
let RegisterRobotAction = require('./RegisterRobotAction.js');
let RegisterRobotActionGoal = require('./RegisterRobotActionGoal.js');
let DeleteRobotAction = require('./DeleteRobotAction.js');
let RegisterRobotResult = require('./RegisterRobotResult.js');
let SpawnRobotGoal = require('./SpawnRobotGoal.js');
let DeleteRobotActionResult = require('./DeleteRobotActionResult.js');
let RegisterRobotFeedback = require('./RegisterRobotFeedback.js');
let DeleteRobotGoal = require('./DeleteRobotGoal.js');
let DeleteRobotFeedback = require('./DeleteRobotFeedback.js');
let SpawnRobotActionGoal = require('./SpawnRobotActionGoal.js');
let RegisterRobotGoal = require('./RegisterRobotGoal.js');
let SpawnRobotResult = require('./SpawnRobotResult.js');
let SpawnRobotFeedback = require('./SpawnRobotFeedback.js');

module.exports = {
  CO2SensorMeasurementMsg: CO2SensorMeasurementMsg,
  CO2Source: CO2Source,
  RfidTagVector: RfidTagVector,
  Noise: Noise,
  ThermalSensorMeasurementMsg: ThermalSensorMeasurementMsg,
  CO2SensorMsg: CO2SensorMsg,
  RfidTag: RfidTag,
  FootprintMsg: FootprintMsg,
  SoundSensorMeasurementMsg: SoundSensorMeasurementMsg,
  ThermalSourceVector: ThermalSourceVector,
  SoundSensorMsg: SoundSensorMsg,
  RfidSensorMeasurementMsg: RfidSensorMeasurementMsg,
  RobotMsg: RobotMsg,
  ThermalSource: ThermalSource,
  ThermalSensorMsg: ThermalSensorMsg,
  SoundSourceVector: SoundSourceVector,
  CO2SourceVector: CO2SourceVector,
  KinematicMsg: KinematicMsg,
  LaserSensorMsg: LaserSensorMsg,
  RfidSensorMsg: RfidSensorMsg,
  SoundSource: SoundSource,
  RobotIndexedVectorMsg: RobotIndexedVectorMsg,
  SonarSensorMsg: SonarSensorMsg,
  RobotIndexedMsg: RobotIndexedMsg,
  RegisterRobotActionFeedback: RegisterRobotActionFeedback,
  DeleteRobotActionFeedback: DeleteRobotActionFeedback,
  SpawnRobotAction: SpawnRobotAction,
  SpawnRobotActionFeedback: SpawnRobotActionFeedback,
  DeleteRobotActionGoal: DeleteRobotActionGoal,
  RegisterRobotActionResult: RegisterRobotActionResult,
  SpawnRobotActionResult: SpawnRobotActionResult,
  DeleteRobotResult: DeleteRobotResult,
  RegisterRobotAction: RegisterRobotAction,
  RegisterRobotActionGoal: RegisterRobotActionGoal,
  DeleteRobotAction: DeleteRobotAction,
  RegisterRobotResult: RegisterRobotResult,
  SpawnRobotGoal: SpawnRobotGoal,
  DeleteRobotActionResult: DeleteRobotActionResult,
  RegisterRobotFeedback: RegisterRobotFeedback,
  DeleteRobotGoal: DeleteRobotGoal,
  DeleteRobotFeedback: DeleteRobotFeedback,
  SpawnRobotActionGoal: SpawnRobotActionGoal,
  RegisterRobotGoal: RegisterRobotGoal,
  SpawnRobotResult: SpawnRobotResult,
  SpawnRobotFeedback: SpawnRobotFeedback,
};
