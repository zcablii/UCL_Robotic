
"use strict";

let Goal = require('./Goal.js')

module.exports = {
  Goal: Goal,
};
