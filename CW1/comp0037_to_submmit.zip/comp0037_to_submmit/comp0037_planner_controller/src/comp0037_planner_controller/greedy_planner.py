# -*- coding: utf-8 -*-

from cell_based_forward_search import CellBasedForwardSearch
from collections import deque



class GREEDYPlanner(CellBasedForwardSearch):

    # Construct the new planner object
    def __init__(self, title, occupancyGrid):
        CellBasedForwardSearch.__init__(self, title, occupancyGrid)
        self.greedyQueue = dict()
		
    def getLength(self):
	return len(self.greedyQueue)
    # sort the queue by the distance to goal
    def pushCellOntoQueue(self, cell):
        cost = self.computeLStageAdditiveCost(self.goal, cell)
        self.greedyQueue[cell] = cost

    # Check the queue size is zero
    def isQueueEmpty(self):
        return not self.greedyQueue

    def popCellFromQueue(self):
        cell = min(self.greedyQueue,key=self.greedyQueue.get)
        del self.greedyQueue[cell]
        return cell

    def resolveDuplicate(self, cell, parentCell):
        # Nothing to do in self case
        pass

